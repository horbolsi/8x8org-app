#!/bin/bash
echo "=== RESTORING 8X8ORG ECOSYSTEM ==="
echo "Signature: 8x8org by FlashTM8 ⚡️"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 20+"
    exit 1
fi

echo "1. Copying files..."
cp -r bots . 2>/dev/null || true
cp -r shared . 2>/dev/null || true
cp -r utils . 2>/dev/null || true
cp -r services . 2>/dev/null || true
cp -r database . 2>/dev/null || true
cp package*.json . 2>/dev/null || true
cp start_*.js . 2>/dev/null || true
cp .env.example . 2>/dev/null || true

echo "2. Installing dependencies..."
npm install

echo "3. Setting up directories..."
mkdir -p backups logs reports logs/admin

echo "4. Configuration instructions:"
echo "   - Copy .env.example to .env"
echo "   - Edit .env with your configuration:"
echo "     • ADMIN_TELEGRAM_ID=YOUR_TELEGRAM_ID"
echo "     • TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN"
echo "     • REPORT_EMAIL=YOUR_EMAIL"
echo "     • EMAIL_USER & EMAIL_PASS for reports"

echo ""
echo "✅ Restoration complete!"
echo ""
echo "To start the system:"
echo "   node start_bots_safe.js"
echo ""
echo "To test:"
echo "   ./test_ecosystem.sh"
echo ""
echo "For help:"
echo "   Check BACKUP_INFO.md"
