module.exports = {
    // Bot identity
    botName: 'IN Bot',
    botUsername: '@in_bot',
    description: 'IN - Tasks for users inside their countries',
    
    // Task settings for internal/local tasks
    tasks: {
        type: 'internal',
        scope: 'local',
        categories: [
            'local_surveys',
            'store_visits',
            'product_reviews',
            'local_promotions',
            'neighborhood_research',
            'community_events'
        ],
        
        // Geographic restrictions
        geo_restrictions: {
            require_location: true,
            radius_km: 50, // Max distance from location
            country_specific: true,
            city_level_targeting: true
        },
        
        // Task requirements
        requirements: {
            location_verification: true,
            local_knowledge: true,
            in_person_possible: true,
            age_restrictions: true
        },
        
        // Rewards
        rewards: {
            currency: 'LOCAL',
            payment_methods: ['local_bank', 'mobile_money', 'cash'],
            min_payout: 5,
            fast_payout: true
        }
    },
    
    // Features
    features: {
        location_services: true,
        local_currency_support: true,
        local_language_support: true,
        offline_capable: true,
        photo_verification: true,
        gps_tracking: false // Privacy-focused
    },
    
    // Integration with main ecosystem
    integration: {
        main_bot: '@app8x8org_bot',
        sync_with_out_bot: true,
        combined_stats: true,
        shared_wallet: true
    },
    
    // Admin settings
    admin: {
        local_moderators: true,
        community_approval: false,
        auto_verification: true,
        local_reporting: true
    },
    
    // Messages
    messages: {
        welcome: "🏠 *Welcome to IN Tasks!*\n\nI handle tasks for users inside their countries.",
        task_complete: "✅ *Local Task Completed!*\nYour local contribution has been recorded.",
        location_notice: "📍 *Note:* These tasks are specific to your local area."
    },
    
    // Signature
    signature: '8x8org by FlashTM8 ⚡️'
};
