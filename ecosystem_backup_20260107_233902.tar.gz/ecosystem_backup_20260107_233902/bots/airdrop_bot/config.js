module.exports = {
    // Bot identity
    botName: 'Airdrop Bot',
    botUsername: '@airdrop_bot',
    description: 'Reward Distribution System',
    
    // Airdrop settings
    airdrops: {
        types: [
            'task_rewards',
            'referral_bonuses',
            'loyalty_rewards',
            'special_campaigns',
            'community_rewards'
        ],
        
        // Distribution rules
        distribution: {
            automated: true,
            scheduled: true,
            conditional: true,
            manual_approval: false,
            batch_processing: true
        },
        
        // Tokens supported
        tokens: [
            { symbol: 'USDT', network: ['ERC20', 'TRC20', 'BEP20'] },
            { symbol: 'ETH', network: ['Ethereum'] },
            { symbol: 'BNB', network: ['BSC'] },
            { symbol: 'MATIC', network: 'Polygon' },
            { symbol: '8X8', network: 'Custom', contract: '0x...' }
        ],
        
        // Requirements
        requirements: {
            min_balance: 0,
            completed_tasks: 1,
            account_age_days: 1,
            kyc_required: false
        }
    },
    
    // Features
    features: {
        multi_token_support: true,
        automatic_distribution: true,
        claim_notifications: true,
        expiration_handling: true,
        tax_calculations: false
    },
    
    // Integration
    integration: {
        with_tasks: true,
        with_wallet: true,
        with_main_bot: true,
        cross_bot_rewards: true
    },
    
    // Admin controls
    admin: {
        create_campaigns: true,
        modify_rewards: true,
        pause_distributions: true,
        view_statistics: true,
        export_reports: true
    },
    
    // Messages
    messages: {
        welcome: "🎁 *Welcome to Airdrop Bot!*\n\nI manage reward distributions.",
        reward_available: "💰 *New Reward Available!*\nYou have received a reward.",
        distribution_complete: "✅ *Distribution Complete*\nRewards have been sent."
    },
    
    // Signature
    signature: '8x8org by FlashTM8 ⚡️'
};
