module.exports = {
    // Bot identity
    botName: 'xorgbytm8_bot',
    botUsername: '@xorgbytm8_bot',
    description: 'OUT - Tasks for users outside their countries',
    
    // Task settings for external/global tasks
    tasks: {
        type: 'external',
        scope: 'global',
        categories: [
            'social_media',
            'content_creation',
            'community_engagement',
            'market_research',
            'translation',
            'international_surveys'
        ],
        
        // Geographic restrictions
        geo_restrictions: {
            allow_all_countries: true,
            blacklist: [], // Countries where tasks are NOT available
            timezone_sensitive: true
        },
        
        // Task requirements
        requirements: {
            min_age: 18,
            language_requirements: ['english'],
            verification_required: true,
            kyc_level: 'basic'
        },
        
        // Rewards
        rewards: {
            currency: 'USD',
            payment_methods: ['crypto', 'paypal', 'bank_transfer'],
            min_payout: 10,
            auto_approval: false
        }
    },
    
    // Features
    features: {
        geo_tracking: true,
        language_detection: true,
        auto_translation: false,
        task_scheduling: true,
        progress_tracking: true,
        certificate_generation: true
    },
    
    // Integration with main ecosystem
    integration: {
        main_bot: '@app8x8org_bot',
        sync_user_data: true,
        share_progress: true,
        unified_wallet: true
    },
    
    // Admin settings
    admin: {
        approval_required: true,
        auto_assign: false,
        quality_control: true,
        report_generation: true
    },
    
    // Messages
    messages: {
        welcome: "🌍 *Welcome to OUT Tasks!*\n\nI handle tasks for users outside their countries.",
        task_complete: "✅ *International Task Completed!*\nYour work has been submitted for review.",
        geo_notice: "📍 *Note:* These tasks are available globally, regardless of your location."
    },
    
    // Signature
    signature: '8x8org by FlashTM8 ⚡️'
};
