const TelegramBot = require('node-telegram-bot-api');
const config = require('./config');
const logger = require('../../utils/logger');

class OutBot {
    constructor() {
        this.token = config.token;
        this.botName = config.botName;
        this.botUsername = config.botUsername;
        
        if (!this.token || this.token.includes('your_') || this.token === '856...ko8') {
            logger.error('❌ Invalid or placeholder bot token detected!');
            logger.error('Please set a valid OUT_BOT_TOKEN in your .env file');
            logger.error('Get a token for @xorgbytm8_bot from @BotFather');
            this.bot = null;
            return;
        }
        
        this.bot = new TelegramBot(this.token, {
            polling: true,
            request: {
                timeout: 60000
            }
        });
        
        this.userSessions = new Map();
        this.initialize();
    }

    async initialize() {
        if (!this.bot) {
            logger.error('❌ Bot not initialized - no valid token');
            return;
        }

        try {
            logger.botEvent(this.botName, 'Initializing xorgbytm8_bot...');
            await this.setupCommands();
            await this.setupListeners();
            
            // Get bot info
            const me = await this.bot.getMe();
            logger.botEvent(this.botName, `Connected as @${me.username} (ID: ${me.id})`);
            console.log(`[${this.botName}] ✅ Bot connected: @${me.username}`);
            console.log(`[${this.botName}] 📋 Bot name: ${me.first_name}`);
            
            // Set bot commands menu
            await this.bot.setMyCommands([
                { command: 'start', description: 'Start the bot' },
                { command: 'tasks', description: 'View available tasks' },
                { command: 'my_tasks', description: 'My active tasks' },
                { command: 'score', description: 'My points score' },
                { command: 'help', description: 'Show help' },
                { command: 'status', description: 'Bot status' }
            ]);
            
        } catch (error) {
            logger.error(`Failed to initialize ${this.botName}:`, error);
            console.log(`[${this.botName}] ❌ Failed to start: ${error.message}`);
        }
    }

    async setupCommands() {
        if (!this.bot) return;

        // ========== COMMAND: /start ==========
        this.bot.onText(/\/start/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const username = msg.from.username || 'User';
            
            logger.userAction(userId, `Started ${this.botName}`);
            
            const welcomeMsg = `🎉 *Welcome to ${this.botUsername}!*\n\n` +
                `I'm your task distribution bot.\n\n` +
                `*Here's what I can do:*\n` +
                `• Assign you tasks to complete\n` +
                `• Track your progress and points\n` +
                `• Reward you for completed tasks\n\n` +
                `*Get started:*\n` +
                `/tasks - View available tasks\n` +
                `/help - Show all commands\n\n` +
                `*Your ID:* ${userId}\n` +
                `*Username:* @${username}`;
            
            await this.bot.sendMessage(chatId, welcomeMsg, { parse_mode: 'Markdown' });
        });

        // ========== COMMAND: /tasks ==========
        this.bot.onText(/\/tasks/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            logger.userAction(userId, `Requested tasks from ${this.botName}`);
            
            const tasks = [
                { id: 1, title: "Join Telegram Group", description: "Join our official group", points: 50 },
                { id: 2, title: "Follow on Twitter", description: "Follow our Twitter account", points: 30 },
                { id: 3, title: "Retweet Announcement", description: "Retweet latest announcement", points: 25 },
                { id: 4, title: "Invite Friends", description: "Invite 3 friends to the bot", points: 100 }
            ];
            
            let message = `📋 *Available Tasks from ${this.botUsername}*\n\n`;
            tasks.forEach(task => {
                message += `*${task.id}. ${task.title}*\n`;
                message += `   ${task.description}\n`;
                message += `   🎯 *Points:* ${task.points}\n`;
                message += `   🚀 */task_${task.id}* to start\n\n`;
            });
            
            await this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        });

        // ========== COMMAND: /task_[id] ==========
        this.bot.onText(/\/task_(\d+)/, async (msg, match) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const taskId = parseInt(match[1]);
            
            logger.userAction(userId, `Started task ${taskId} on ${this.botName}`);
            
            await this.bot.sendMessage(chatId,
                `✅ *Task ${taskId} Started!*\n\n` +
                `Great! You've started a task.\n\n` +
                `*To complete:*\n` +
                `1. Complete the task requirements\n` +
                `2. Take a screenshot if needed\n` +
                `3. Use /submit_${taskId} when done\n\n` +
                `🎯 *Points:* 50\n` +
                `⏱️ *Time limit:* 24 hours`,
                { parse_mode: 'Markdown' }
            );
        });

        // ========== COMMAND: /submit_[id] ==========
        this.bot.onText(/\/submit_(\d+)/, async (msg, match) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const taskId = parseInt(match[1]);
            
            logger.userAction(userId, `Submitted task ${taskId} on ${this.botName}`);
            
            await this.bot.sendMessage(chatId,
                `🎯 *Task ${taskId} Submitted!*\n\n` +
                `Your submission has been received.\n\n` +
                `*Status:* Under review\n` +
                `*Points pending:* 50\n` +
                `*Estimated review:* 1-2 hours\n\n` +
                `We'll notify you when it's approved!`,
                { parse_mode: 'Markdown' }
            );
        });

        // ========== COMMAND: /my_tasks ==========
        this.bot.onText(/\/my_tasks/, async (msg) => {
            const chatId = msg.chat.id;
            
            await this.bot.sendMessage(chatId,
                `📊 *Your Active Tasks*\n\n` +
                `*1. Join Telegram Group*\n` +
                `   Status: In Progress\n` +
                `   Started: 2 hours ago\n` +
                `   Points: 50\n\n` +
                `*2. Follow on Twitter*\n` +
                `   Status: Completed ✓\n` +
                `   Points earned: 30\n\n` +
                `*Total points:* 30\n` +
                `*Tasks completed:* 1/2`,
                { parse_mode: 'Markdown' }
            );
        });

        // ========== COMMAND: /score ==========
        this.bot.onText(/\/score/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            await this.bot.sendMessage(chatId,
                `🏆 *Your Score*\n\n` +
                `*Total Points:* 150\n` +
                `*Rank:* #42\n` +
                `*Tasks Completed:* 5\n` +
                `*Success Rate:* 92%\n\n` +
                `*Recent Points:*\n` +
                `• Task #3: +25 points\n` +
                `• Task #5: +50 points\n` +
                `• Daily bonus: +10 points\n\n` +
                `Keep up the great work! 🚀`,
                { parse_mode: 'Markdown' }
            );
        });

        // ========== COMMAND: /status ==========
        this.bot.onText(/\/status/, async (msg) => {
            const chatId = msg.chat.id;
            const memory = process.memoryUsage();
            
            await this.bot.sendMessage(chatId,
                `⚙️ *${this.botUsername} Status*\n\n` +
                `✅ *Bot:* Online\n` +
                `👤 *Users:* 1,234\n` +
                `📊 *Tasks:* 42 active\n` +
                `🕒 *Uptime:* ${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m\n` +
                `💾 *Memory:* ${Math.round(memory.heapUsed / 1024 / 1024)}MB\n` +
                `📈 *Version:* 1.0.0`,
                { parse_mode: 'Markdown' }
            );
        });

        // ========== COMMAND: /help ==========
        this.bot.onText(/\/help/, async (msg) => {
            const chatId = msg.chat.id;
            
            const helpMsg = `🤖 *${this.botUsername} Help*\n\n` +
                `*Task Commands:*\n` +
                `/tasks - View all available tasks\n` +
                `/task_[id] - Start a specific task\n` +
                `/submit_[id] - Submit completed task\n` +
                `/my_tasks - View your active tasks\n` +
                `/score - Check your points and rank\n\n` +
                `*Info Commands:*\n` +
                `/start - Welcome message\n` +
                `/status - Bot status\n` +
                `/help - This message\n\n` +
                `*How it works:*\n` +
                `1. Browse tasks with /tasks\n` +
                `2. Start a task with /task_[id]\n` +
                `3. Complete the requirements\n` +
                `4. Submit with /submit_[id]\n` +
                `5. Earn points and climb ranks!\n\n` +
                `*Need help?* Contact the admin.`;
            
            await this.bot.sendMessage(chatId, helpMsg, { parse_mode: 'Markdown' });
        });

        logger.botEvent(this.botName, 'Commands setup complete');
    }

    async setupListeners() {
        if (!this.bot) return;
        
        // Error handling
        this.bot.on('error', (error) => {
            logger.error(`${this.botName} error:`, error);
        });
        
        // Polling error
        this.bot.on('polling_error', (error) => {
            console.log(`[${this.botName}] Polling error: ${error.message}`);
        });
        
        // Message listener
        this.bot.on('message', (msg) => {
            if (!msg.text || msg.text.startsWith('/')) return;
            
            // Handle regular messages
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            // Log message
            logger.userAction(userId, `Sent message: ${msg.text.substring(0, 50)}...`);
        });
        
        logger.botEvent(this.botName, 'Listeners setup complete');
    }

    async stop() {
        if (this.bot) {
            try {
                this.bot.stopPolling();
                logger.botEvent(this.botName, 'Stopped polling');
            } catch (error) {
                logger.error(`Error stopping ${this.botName}:`, error);
            }
        }
    }
}

// If run directly
if (require.main === module) {
    const bot = new OutBot();
    
    // Graceful shutdown
    process.once('SIGINT', () => {
        console.log(`\n[${bot.botName}] Shutting down...`);
        bot.stop();
        process.exit(0);
    });
    
    process.once('SIGTERM', () => {
        console.log(`\n[${bot.botName}] Terminating...`);
        bot.stop();
        process.exit(0);
    });
    
    // Keep process alive
    console.log(`[${bot.botName}] Running as xorgbytm8_bot`);
} else {
    // Export for use by other modules
    async function startOutBot() {
        try {
            const bot = new OutBot();
            logger.botEvent('OUT', 'xorgbytm8_bot instance created');
            return bot;
        } catch (error) {
            logger.error('Failed to start xorgbytm8_bot:', error);
            return null;
        }
    }
    
    module.exports = { OutBot, startOutBot };
}
