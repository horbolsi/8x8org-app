const TelegramBot = require('node-telegram-bot-api');
const adminConfig = require('../../shared/admin_config');
const { logAction } = require('../../shared/middleware/admin_auth');
const logger = require('../../utils/logger');

class MainBot {
    constructor() {
        this.token = process.env.MAIN_BOT_TOKEN || process.env.APP_BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN;
        this.botName = 'app8x8org_bot';
        this.botUsername = '@app8x8org_bot';
        this.adminConfig = adminConfig;
        
        if (!this.token) {
            logger.error('❌ Main Bot token not configured');
            return;
        }
        
        this.bot = new TelegramBot(this.token, {
            polling: true,
            request: { timeout: 60000 }
        });
        
        this.initialize();
    }

    async initialize() {
        try {
            logger.botEvent(this.botName, 'Initializing User Interface Bot...');
            
            await this.setupCommands();
            await this.setupListeners();
            
            const me = await this.bot.getMe();
            logger.botEvent(this.botName, `Connected as @${me.username}`);
            console.log(`[${this.botName}] ✅ User Interface Bot Ready`);
            console.log(`[${this.botName}] 👑 Admin: ${this.adminConfig.owner.username}`);
            
        } catch (error) {
            logger.error(`Failed to initialize ${this.botName}:`, error);
        }
    }

    async setupCommands() {
        // ========== PUBLIC COMMANDS (All Users) ==========
        
        // Start command - Available to all
        this.bot.onText(/\/start/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const username = msg.from.username || 'User';
            
            logAction(userId, 'started_main_bot', { username });
            
            const welcomeMsg = `👋 *Welcome to 8x8org Ecosystem!*\n\n` +
                `I'm your personal interface to the ecosystem.\n\n` +
                `*Your Account:*\n` +
                `👤 User: @${username}\n` +
                `🆔 ID: ${userId}\n\n` +
                `*Available Features:*\n` +
                `📊 Dashboard - Your account overview\n` +
                `📋 Tasks - Available tasks (IN/OUT)\n` +
                `💰 Wallet - Crypto wallet management\n` +
                `🎨 NFT - NFT marketplace\n` +
                `📈 Progress - Your statistics\n\n` +
                `*Quick Commands:*\n` +
                `/dashboard - Your account dashboard\n` +
                `/profile - View your profile\n` +
                `/help - Show all commands\n\n` +
                `${this.adminConfig.getSignature()}`;
            
            await this.bot.sendMessage(chatId, welcomeMsg, { parse_mode: 'Markdown' });
        });

        // Help command - Available to all
        this.bot.onText(/\/help/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            const helpMsg = `🤖 *8x8org Ecosystem Help*\n\n` +
                `*Account Commands:*\n` +
                `/start - Welcome message\n` +
                `/dashboard - Your dashboard\n` +
                `/profile - Your profile\n` +
                `/balance - Account balance\n` +
                `/stats - Your statistics\n\n` +
                `*Feature Access:*\n` +
                `/tasks - Access task system\n` +
                `/wallet - Open wallet manager\n` +
                `/nft - Browse NFT marketplace\n` +
                `/rewards - View available rewards\n\n` +
                `*Support:*\n` +
                `/help - This message\n` +
                `/contact - Contact support\n\n` +
                `${this.adminConfig.getSignature()}`;
            
            await this.bot.sendMessage(chatId, helpMsg, { parse_mode: 'Markdown' });
        });

        // Dashboard command - Available to all
        this.bot.onText(/\/dashboard/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const username = msg.from.username || 'User';
            
            logAction(userId, 'accessed_dashboard', { username });
            
            const dashboardMsg = `📊 *Your Dashboard*\n\n` +
                `*Account Summary:*\n` +
                `👤 User: @${username}\n` +
                `🆔 ID: ${userId}\n` +
                `📅 Member since: Today\n\n` +
                `*Statistics:*\n` +
                `✅ Tasks completed: 0\n` +
                `💰 Total earned: $0.00\n` +
                `🎯 Success rate: 0%\n` +
                `🏆 Rank: New member\n\n` +
                `*Quick Actions:*\n` +
                `• Browse tasks: /tasks\n` +
                `• Check wallet: /wallet\n` +
                `• View NFTs: /nft\n\n` +
                `${this.adminConfig.getSignature()}`;
            
            await this.bot.sendMessage(chatId, dashboardMsg, { parse_mode: 'Markdown' });
        });

        // ========== ADMIN-ONLY COMMANDS ==========
        
        // Admin command - Only for owner
        this.bot.onText(/\/admin/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            if (!this.adminConfig.isAdmin(userId)) {
                logAction(userId, 'unauthorized_admin_access_attempt', {});
                return this.bot.sendMessage(chatId, 
                    `⛔ *Access Denied*\n\n` +
                    `Admin panel is restricted to system owner only.\n\n` +
                    `${this.adminConfig.getSignature()}`,
                    { parse_mode: 'Markdown' }
                );
            }
            
            logAction(userId, 'accessed_admin_panel', {});
            
            const adminMsg = `👑 *Admin Panel - 8x8org Ecosystem*\n\n` +
                `*Owner:* ${this.adminConfig.owner.username}\n` +
                `*System:* ${this.adminConfig.system.name}\n` +
                `*Version:* ${this.adminConfig.system.version}\n\n` +
                `*Admin Commands:*\n` +
                `/users - View all users\n` +
                `/stats - System statistics\n` +
                `/export - Export data (Excel)\n` +
                `/backup - Create system backup\n` +
                `/broadcast - Send message to all users\n` +
                `/config - System configuration\n` +
                `/restart - Restart bots\n\n` +
                `*Bot Status:*\n` +
                `• Main Bot: ✅ Online\n` +
                `• OUT Bot: ✅ Online\n` +
                `• IN Bot: ✅ Online\n` +
                `• Airdrop Bot: ✅ Online\n` +
                `• Wallet Bot: ✅ Online\n` +
                `• NFT Bot: ✅ Online\n\n` +
                `${this.adminConfig.getSignature()}`;
            
            await this.bot.sendMessage(chatId, adminMsg, { parse_mode: 'Markdown' });
        });

        // Export command - Only for owner
        this.bot.onText(/\/export/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            if (!this.adminConfig.isAdmin(userId)) {
                return this.bot.sendMessage(chatId, '⛔ Access Denied');
            }
            
            logAction(userId, 'requested_export', {});
            
            await this.bot.sendMessage(chatId, 
                `📤 *Generating Report...*\n\n` +
                `Creating Excel report with all system data.\n` +
                `Report will be sent to owner's email.\n\n` +
                `${this.adminConfig.getSignature()}`,
                { parse_mode: 'Markdown' }
            );
            
            // Simulate report generation
            setTimeout(async () => {
                await this.bot.sendMessage(chatId,
                    `✅ *Report Generated*\n\n` +
                    `Excel report has been generated and sent to:\n` +
                    `📧 ${this.adminConfig.owner.email}\n\n` +
                    `*Report includes:*\n` +
                    `• User statistics\n` +
                    `• Transaction history\n` +
                    `• Task completion data\n` +
                    `• System performance\n\n` +
                    `${this.adminConfig.getSignature()}`,
                    { parse_mode: 'Markdown' }
                );
            }, 3000);
        });

        // ========== FEATURE ACCESS COMMANDS ==========
        
        // Tasks command - Redirects to appropriate bot
        this.bot.onText(/\/tasks/, async (msg) => {
            const chatId = msg.chat.id;
            
            await this.bot.sendMessage(chatId,
                `📋 *Task System*\n\n` +
                `Choose task type:\n\n` +
                `*🌍 OUT Tasks* (Outside your country)\n` +
                `Available via: @xorgbytm8_bot\n` +
                `Use: /tasks in that bot\n\n` +
                `*🏠 IN Tasks* (Inside your country)\n` +
                `Available via: IN Bot\n` +
                `Coming soon!\n\n` +
                `*Note:* Each bot handles specific task types.\n` +
                `You need to start each bot separately.\n\n` +
                `${this.adminConfig.getSignature()}`,
                { parse_mode: 'Markdown' }
            );
        });

        // Wallet command
        this.bot.onText(/\/wallet/, async (msg) => {
            const chatId = msg.chat.id;
            
            await this.bot.sendMessage(chatId,
                `💰 *Wallet Manager*\n\n` +
                `Access your crypto wallet:\n` +
                `Available via: Wallet Bot\n\n` +
                `*Features:*\n` +
                `• Multi-chain support\n` +
                `• Balance checking\n` +
                `• Send/receive tokens\n` +
                `• Transaction history\n\n` +
                `${this.adminConfig.getSignature()}`,
                { parse_mode: 'Markdown' }
            );
        });

        // NFT command
        this.bot.onText(/\/nft/, async (msg) => {
            const chatId = msg.chat.id;
            
            await this.bot.sendMessage(chatId,
                `🎨 *NFT Marketplace*\n\n` +
                `Browse and trade NFTs:\n` +
                `Available via: NFT Bot\n\n` +
                `*Features:*\n` +
                `• NFT collections\n` +
                `• Marketplace\n` +
                `• Your NFTs\n` +
                `• Trading\n\n` +
                `${this.adminConfig.getSignature()}`,
                { parse_mode: 'Markdown' }
            );
        });

        logger.botEvent(this.botName, 'Commands setup complete');
    }

    async setupListeners() {
        this.bot.on('error', (error) => {
            logger.error(`${this.botName} error:`, error);
        });
        
        // Log all messages from admin
        this.bot.on('message', (msg) => {
            if (this.adminConfig.isAdmin(msg.from.id)) {
                logAction(msg.from.id, 'sent_message', {
                    text: msg.text?.substring(0, 100),
                    chat_id: msg.chat.id
                });
            }
        });
        
        logger.botEvent(this.botName, 'Listeners setup complete');
    }

    async stop() {
        if (this.bot) {
            try {
                this.bot.stopPolling();
                logger.botEvent(this.botName, 'Stopped');
            } catch (error) {
                logger.error(`Error stopping ${this.botName}:`, error);
            }
        }
    }
}

// Export for system startup
if (require.main === module) {
    const bot = new MainBot();
    
    process.once('SIGINT', () => {
        console.log(`\n[${bot.botName}] Shutting down...`);
        bot.stop();
        process.exit(0);
    });
    
    process.once('SIGTERM', () => {
        console.log(`\n[${bot.botName}] Terminating...`);
        bot.stop();
        process.exit(0);
    });
    
    console.log(`[${bot.botName}] Starting User Interface Bot...`);
} else {
    module.exports = { MainBot };
}
