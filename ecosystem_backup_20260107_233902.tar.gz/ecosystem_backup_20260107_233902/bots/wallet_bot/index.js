const { ethers } = require('ethers');
const axios = require('axios');
require('dotenv').config();

class WalletBot {
    constructor() {
        console.log('🔐 Wallet Bot Initializing...');
        
        // Use public, free RPC endpoints that work without auth
        this.config = {
            networks: {
                ethereum: process.env.ETH_RPC || 'https://eth.llamarpc.com',
                polygon: process.env.POLYGON_RPC || 'https://polygon-rpc.com',
                bsc: process.env.BSC_RPC || 'https://bsc.publicnode.com'
            }
        };
        
        this.providers = {};
        this.initializeProviders();
    }
    
    initializeProviders() {
        console.log('🌐 Initializing blockchain providers...');
        for (const [network, rpcUrl] of Object.entries(this.config.networks)) {
            try {
                // Use static network to avoid auto-detection issues
                let networkObj;
                switch(network) {
                    case 'ethereum': networkObj = 'mainnet'; break;
                    case 'polygon': networkObj = 'matic'; break;
                    case 'bsc': networkObj = { chainId: 56, name: 'bsc' }; break;
                    default: networkObj = 'homestead';
                }
                
                this.providers[network] = new ethers.JsonRpcProvider(rpcUrl, networkObj);
                console.log(`   ✅ ${network}: Connected`);
            } catch (error) {
                console.log(`   ⚠️ ${network}: ${error.message}`);
            }
        }
    }
    
    async getBalance(address, network = 'ethereum') {
        try {
            const provider = this.providers[network];
            if (!provider) {
                console.log(`⚠️ No provider for ${network}, using fallback`);
                return await this.getBalanceFallback(address, network);
            }
            
            console.log(`💰 Checking balance for ${address.slice(0, 10)}... on ${network}`);
            
            // Add timeout to avoid hanging
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Timeout')), 10000)
            );
            
            const balancePromise = provider.getBalance(address);
            const balance = await Promise.race([balancePromise, timeoutPromise]);
            const formattedBalance = ethers.formatEther(balance);
            
            return {
                success: true,
                network,
                address,
                balance: formattedBalance,
                currency: network === 'bsc' ? 'BNB' : 'ETH'
            };
        } catch (error) {
            console.log(`❌ Balance check failed: ${error.message}`);
            return await this.getBalanceFallback(address, network);
        }
    }
    
    async getBalanceFallback(address, network) {
        try {
            console.log(`🔄 Using fallback method for ${network}...`);
            
            let apiUrl;
            switch(network) {
                case 'ethereum':
                    apiUrl = `https://api.etherscan.io/api?module=account&action=balance&address=${address}&tag=latest`;
                    break;
                case 'polygon':
                    apiUrl = `https://api.polygonscan.com/api?module=account&action=balance&address=${address}&tag=latest`;
                    break;
                case 'bsc':
                    apiUrl = `https://api.bscscan.com/api?module=account&action=balance&address=${address}&tag=latest`;
                    break;
                default:
                    return {
                        success: false,
                        error: `Unsupported network: ${network}`,
                        address
                    };
            }
            
            // Add API key if available
            if (process.env.ETHERSCAN_API_KEY && network === 'ethereum') {
                apiUrl += `&apikey=${process.env.ETHERSCAN_API_KEY}`;
            }
            
            const response = await axios.get(apiUrl);
            
            if (response.data.status === '1') {
                const balanceWei = response.data.result;
                const balance = ethers.formatEther(balanceWei);
                
                return {
                    success: true,
                    network,
                    address,
                    balance,
                    balanceWei,
                    source: 'explorer-api',
                    currency: network === 'bsc' ? 'BNB' : 'ETH'
                };
            } else {
                return {
                    success: false,
                    error: response.data.message || 'API error',
                    address
                };
            }
        } catch (error) {
            return {
                success: false,
                error: error.message,
                address,
                network
            };
        }
    }
    
    createWallet(network = 'ethereum', label = '') {
        try {
            console.log('🆕 Creating new wallet...');
            const wallet = ethers.Wallet.createRandom();
            
            return {
                success: true,
                address: wallet.address,
                privateKey: wallet.privateKey,
                mnemonic: wallet.mnemonic?.phrase,
                network,
                label: label || `Wallet_${Date.now()}`,
                created: new Date().toISOString(),
                warning: '⚠️ SECURITY WARNING: NEVER share private key or mnemonic!'
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    // Get crypto prices from Coingecko
    async getCryptoPrices() {
        try {
            const response = await axios.get(
                'https://api.coingecko.com/api/v3/simple/price?ids=ethereum,binancecoin&vs_currencies=usd'
            );
            
            return {
                success: true,
                prices: response.data,
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            console.log('⚠️ Using fallback prices');
            return {
                success: true,
                prices: {
                    ethereum: { usd: 2500 },
                    binancecoin: { usd: 350 }
                },
                source: 'fallback'
            };
        }
    }
    
    start() {
        console.log('🚀 Wallet Bot Started Successfully!');
        console.log('🌐 Networks available:', Object.keys(this.providers));
        
        // Show test address
        console.log('\n🧪 Test Commands:');
        console.log('   const bot = new WalletBot();');
        console.log('   await bot.getBalance("0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045")');
        console.log('   await bot.createWallet("ethereum", "My Wallet")');
        
        return this;
    }
}

module.exports = WalletBot;

if (require.main === module) {
    const walletBot = new WalletBot();
    
    // Start the bot
    walletBot.start();
    
    // Run test if --test flag provided
    if (process.argv.includes('--test')) {
        console.log('\n🧪 Running wallet bot test...');
        
        // Test 1: Create wallet
        const newWallet = walletBot.createWallet();
        console.log('✅ Test 1 - Create Wallet:');
        console.log(`   Address: ${newWallet.address}`);
        console.log(`   Created: ${newWallet.created}`);
        
        // Test 2: Get Vitalik's balance (async)
        setTimeout(async () => {
            try {
                const balance = await walletBot.getBalance('0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045');
                console.log('\n✅ Test 2 - Get Balance:');
                if (balance.success) {
                    console.log(`   Address: ${balance.address.slice(0, 10)}...`);
                    console.log(`   Balance: ${balance.balance} ${balance.currency}`);
                } else {
                    console.log(`   Error: ${balance.error}`);
                }
            } catch (error) {
                console.log(`   Error: ${error.message}`);
            }
        }, 1000);
        
        // Test 3: Get prices
        setTimeout(async () => {
            try {
                const prices = await walletBot.getCryptoPrices();
                console.log('\n✅ Test 3 - Crypto Prices:');
                console.log(`   ETH: $${prices.prices.ethereum?.usd || 'N/A'}`);
                console.log(`   BNB: $${prices.prices.binancecoin?.usd || 'N/A'}`);
            } catch (error) {
                console.log(`   Price check error: ${error.message}`);
            }
        }, 2000);
    }
}
