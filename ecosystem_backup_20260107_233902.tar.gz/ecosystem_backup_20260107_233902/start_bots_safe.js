console.log(`
╔════════════════════════════════════════════╗
║         SAFE BOT STARTUP SYSTEM            ║
╚════════════════════════════════════════════╝
`);

const fs = require('fs');
const { spawn } = require('child_process');

class SafeBotStarter {
    constructor() {
        this.bots = [
            { name: 'Main Bot', file: 'bots/main_bot/index.js', essential: false },
            { name: 'Airdrop Bot', file: 'bots/airdrop_bot/index.js', essential: false },
            { name: 'In Bot', file: 'bots/in_bot/index.js', essential: false },
            { name: 'Out Bot', file: 'bots/out_bot/index.js', essential: false },
            { name: 'Wallet Bot', file: 'bots/wallet_bot/index.js', essential: true, new: true },
            { name: 'NFT Bot', file: 'bots/nft_marketplace/index.js', essential: false, new: true }
        ];
        
        this.processes = [];
        this.startTime = new Date();
    }
    
    async start() {
        console.log('🚀 Starting bots safely...\n');
        
        // Create logs directory
        if (!fs.existsSync('logs')) {
            fs.mkdirSync('logs');
        }
        
        // Start each bot
        for (const bot of this.bots) {
            await this.startBot(bot);
            await this.sleep(1000); // Delay between starts
        }
        
        console.log(`\n✅ Started ${this.processes.length} bot(s)`);
        this.printStatus();
        
        // Start monitoring
        this.startMonitoring();
        
        // Keep process alive
        this.keepAlive();
    }
    
    async startBot(bot) {
        return new Promise((resolve) => {
            // Check if file exists
            if (!fs.existsSync(bot.file)) {
                console.log(`⏭️ Skipping ${bot.name}: File not found`);
                resolve();
                return;
            }
            
            console.log(`▶️ Starting ${bot.name}...`);
            
            try {
                const process = spawn('node', [bot.file], {
                    stdio: 'pipe',
                    detached: false
                });
                
                const processInfo = {
                    name: bot.name,
                    process,
                    pid: process.pid,
                    startTime: new Date(),
                    logs: []
                };
                
                // Capture output
                process.stdout.on('data', (data) => {
                    const log = data.toString().trim();
                    processInfo.logs.push(log);
                    console.log(`   [${bot.name}] ${log}`);
                });
                
                process.stderr.on('data', (data) => {
                    const error = data.toString().trim();
                    processInfo.logs.push(`ERROR: ${error}`);
                    console.log(`   [${bot.name}] ⚠️ ${error}`);
                });
                
                process.on('close', (code) => {
                    processInfo.endTime = new Date();
                    processInfo.exitCode = code;
                    console.log(`   [${bot.name}] Exited with code ${code}`);
                });
                
                this.processes.push(processInfo);
                console.log(`   ✅ ${bot.name} started (PID: ${process.pid})`);
                
            } catch (error) {
                console.log(`   ❌ Failed to start ${bot.name}: ${error.message}`);
            }
            
            resolve();
        });
    }
    
    printStatus() {
        console.log('\n📊 BOT STATUS');
        console.log('════════════════════════');
        
        const uptime = Math.floor((new Date() - this.startTime) / 1000);
        const running = this.processes.filter(p => !p.process.killed).length;
        
        console.log(`Uptime: ${this.formatTime(uptime)}`);
        console.log(`Total: ${this.processes.length} bots, ${running} running`);
        
        this.processes.forEach((p, i) => {
            const status = p.process.killed ? '🔴 STOPPED' : '🟢 RUNNING';
            console.log(`${i + 1}. ${p.name}: ${status} (PID: ${p.pid})`);
        });
        
        console.log('════════════════════════\n');
    }
    
    startMonitoring() {
        // Status check every 30 seconds
        setInterval(() => {
            this.printStatus();
        }, 30000);
        
        console.log('📈 Monitoring active (updates every 30s)\n');
    }
    
    keepAlive() {
        // Keep main process running
        setInterval(() => {
            // Just keep alive
        }, 60000);
        
        console.log('💖 System active. Press Ctrl+C to exit.\n');
    }
    
    async shutdown() {
        console.log('\n🛑 Shutting down...');
        
        for (const p of this.processes) {
            try {
                if (!p.process.killed) {
                    p.process.kill('SIGTERM');
                    console.log(`   Stopped ${p.name}`);
                }
            } catch (error) {
                // Ignore
            }
        }
        
        console.log('\n👋 Shutdown complete.');
        process.exit(0);
    }
    
    formatTime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        return `${hours}h ${minutes}m ${secs}s`;
    }
    
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Handle command line arguments
const args = process.argv.slice(2);
const starter = new SafeBotStarter();

if (args.includes('--help') || args.includes('-h')) {
    console.log(`
Usage: node start_bots_safe.js [options]

Options:
  --help, -h     Show this help
  --test         Run in test mode
  --wallet-only  Start only wallet bot
  --nft-only     Start only NFT bot
  
Examples:
  node start_bots_safe.js          # Start all bots
  node start_bots_safe.js --test   # Test mode
    `);
    process.exit(0);
}

if (args.includes('--test')) {
    console.log('🧪 Test mode: Starting minimal setup...');
    starter.bots = starter.bots.filter(bot => bot.name.includes('Wallet') || bot.name.includes('NFT'));
}

if (args.includes('--wallet-only')) {
    console.log('🔐 Starting only Wallet Bot...');
    starter.bots = starter.bots.filter(bot => bot.name.includes('Wallet'));
}

if (args.includes('--nft-only')) {
    console.log('🖼️ Starting only NFT Bot...');
    starter.bots = starter.bots.filter(bot => bot.name.includes('NFT'));
}

// Start the system
starter.start().catch(console.error);

// Handle shutdown
process.on('SIGINT', () => starter.shutdown());
process.on('SIGTERM', () => starter.shutdown());
